import random
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import UploadFileForm
from .models import QuestionAnswer
from django.contrib.auth import authenticate,login
from django.contrib.auth.decorators import login_required
from .forms import LoginForm

# @login_required
# def upload_file(request):
#     if request.method == 'POST':
#         form = UploadFileForm(request.POST, request.FILES)
#         if form.is_valid():
#             handle_uploaded_file(request.FILES['file'])
#             return redirect('generate_crossword')
#     else:
#         form = UploadFileForm()
#     return render(request, 'crossword_app/upload.html', {'form': form})
# pass
# def handle_uploaded_file(file):
#     # Clear the existing entries in the QuestionAnswer model
#     QuestionAnswer.objects.all().delete()
    
#     for line in file:
#         question, answer = line.decode('utf-8').strip().split(':')
#         QuestionAnswer.objects.create(question=question, answer=answer)

# def generate_crossword(request):
#     question_answers = list(QuestionAnswer.objects.all())
#     random.shuffle(question_answers)
#     grid, positions = create_crossword(question_answers)
#     return render(request, 'crossword_app/crossword.html', {'grid': grid, 'positions': positions, 'questions': question_answers})

# def create_crossword(question_answers):
#     size = 15
#     grid = [[(' ', None) for _ in range(size)] for _ in range(size)]
#     positions = []

#     def can_place_horizontally(x, y, word):
#         if y + len(word) > size:
#             return False
#         for j in range(len(word)):
#             if grid[x][y + j][0] not in (' ', word[j]):
#                 return False
#         return True

#     def can_place_vertically(x, y, word):
#         if x + len(word) > size:
#             return False
#         for j in range(len(word)):
#             if grid[x + j][y][0] not in (' ', word[j]):
#                 return False
#         return True

#     def place_horizontally(x, y, word, number):
#         for j in range(len(word)):
#             if j == 0:
#                 grid[x][y + j] = (word[j], number)
#             else:
#                 grid[x][y + j] = (word[j], None)

#     def place_vertically(x, y, word, number):
#         for j in range(len(word)):
#             if j == 0:
#                 grid[x + j][y] = (word[j], number)
#             else:
#                 grid[x + j][y] = (word[j], None)

#     for i, qa in enumerate(question_answers):
#         answer = qa.answer.upper()
#         number = i + 1
#         placed = False
#         attempts = 0

#         while not placed and attempts < 100:  # Try 100 times to place the word
#             if i % 2 == 0:  # Horizontal placement
#                 x = random.randint(0, size - 1)
#                 y = random.randint(0, size - len(answer))
#                 if can_place_horizontally(x, y, answer):
#                     place_horizontally(x, y, answer, number)
#                     positions.append((qa.question, x, y, 'H'))
#                     placed = True
#             else:  # Vertical placement
#                 x = random.randint(0, size - len(answer))
#                 y = random.randint(0, size - 1)
#                 if can_place_vertically(x, y, answer):
#                     place_vertically(x, y, answer, number)
#                     positions.append((qa.question, x, y, 'V'))
#                     placed = True

#             attempts += 1

#     return grid, positions





import random
from django.shortcuts import render, redirect
from .forms import UploadFileForm
from .models import QuestionAnswer

@login_required
def upload_file(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            handle_uploaded_file(request.FILES['file'])
            # Clear the session to force regeneration of crossword
            if 'crossword_grid' in request.session:
                del request.session['crossword_grid']
            return redirect('generate_crossword')
    else:
        form = UploadFileForm()
    return render(request, 'crossword_app/upload.html', {'form': form})
pass

def handle_uploaded_file(file):
    # Clear the existing entries in the QuestionAnswer model
    QuestionAnswer.objects.all().delete()
    
    for line in file:
        question, answer = line.decode('utf-8').strip().split(':')
        QuestionAnswer.objects.create(question=question, answer=answer)

def generate_crossword(request):
    if 'crossword_grid' in request.session:
        grid = request.session['crossword_grid']
    else:
        question_answers = list(QuestionAnswer.objects.all())
        random.shuffle(question_answers)
        grid = create_crossword(question_answers)
        request.session['crossword_grid'] = grid
    
    question_answers = list(QuestionAnswer.objects.all())
    positions = get_positions(grid, question_answers)
    
    return render(request, 'crossword_app/crossword.html', {'grid': grid, 'positions': positions, 'questions': question_answers})

def create_crossword(question_answers):
    size = 15
    grid = [[(' ', None) for _ in range(size)] for _ in range(size)]

    def can_place_horizontally(x, y, word):
        if y + len(word) > size:
            return False
        for j in range(len(word)):
            if grid[x][y + j][0] not in (' ', word[j]):
                return False
        return True

    def can_place_vertically(x, y, word):
        if x + len(word) > size:
            return False
        for j in range(len(word)):
            if grid[x + j][y][0] not in (' ', word[j]):
                return False
        return True

    def place_horizontally(x, y, word, number):
        for j in range(len(word)):
            if j == 0:
                grid[x][y + j] = (word[j], number, 'H')
            else:
                grid[x][y + j] = (word[j], None, 'H')

    def place_vertically(x, y, word, number):
        for j in range(len(word)):
            if j == 0:
                grid[x + j][y] = (word[j], number, 'V')
            else:
                grid[x + j][y] = (word[j], None, 'V')

    for i, qa in enumerate(question_answers):
        answer = qa.answer.upper()
        number = i + 1
        placed = False
        attempts = 0

        while not placed and attempts < 100:  # Try 100 times to place the word
            if i % 2 == 0:  # Horizontal placement
                x = random.randint(0, size - 1)
                y = random.randint(0, size - len(answer))
                if can_place_horizontally(x, y, answer):
                    place_horizontally(x, y, answer, number)
                    placed = True
            else:  # Vertical placement
                x = random.randint(0, size - len(answer))
                y = random.randint(0, size - 1)
                if can_place_vertically(x, y, answer):
                    place_vertically(x, y, answer, number)
                    placed = True

            attempts += 1

    return grid

def get_positions(grid, question_answers):
    positions = []
    for i, row in enumerate(grid):
        for j, cell in enumerate(row):
            if len(cell) > 1 and cell[1] is not None:  # Ensure tuple has at least 2 elements
                number = cell[1]
                orientation = cell[2] if len(cell) > 2 else None  # Handle optional orientation
                for question_answer in question_answers:
                    if question_answer.answer.upper().startswith(cell[0]):  # Match first letter of answer
                        question = question_answer.question
                        positions.append((question, i, j, orientation))
    
    return positions

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('upload_file')
            else:
                form.add_error(None, 'Invalid username or password')
    else:
        form = LoginForm()
    return render(request, 'crossword_app/login.html', {'form': form})