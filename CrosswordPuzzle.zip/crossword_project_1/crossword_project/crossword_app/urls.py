from django.urls import path
from . views import login_view,upload_file,generate_crossword


urlpatterns = [
    path('login/',login_view,name='login'),
    path('upload/', upload_file, name='upload_file'),
    path('generate/', generate_crossword, name='generate_crossword'),
  
]
