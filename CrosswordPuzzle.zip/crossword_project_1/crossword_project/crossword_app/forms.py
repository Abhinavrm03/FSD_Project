from django import forms
from django.contrib.auth.models import User
class UploadFileForm(forms.Form):
    file = forms.FileField()
class LoginForm(forms.Form):
    username = forms.CharField(max_length=150, required=True,widget=forms.TextInput(attrs={'placeholder':'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'Password'}), required=True)
    department = forms.ChoiceField(choices=[
        ('','Select:'),
        ('CSE', 'CSE'),
        ('ISE', 'ISE'),
        ('ME', 'ME'),
        ('ECE', 'ECE'),
        ('CSD', 'CSD')
    ])
